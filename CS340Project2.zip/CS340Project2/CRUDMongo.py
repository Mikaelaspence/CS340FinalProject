from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelterCRUD:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password, host, port, db_name, collection_name):
        """Initialize the MongoClient and establish connection"""
        print(f'mongodb://{username}:{password}@{host}:{port}/{db_name}')
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}')
        self.db = self.client[db_name]
        self.collection = self.db[collection_name]

    def create(self, data):
        """Insert a document into the collection"""
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred while inserting document: {e}")
                return False
        else:
            raise ValueError("Data cannot be empty")

    def read(self, query):
        """Query documents from the collection"""
        try:
            cursor = self.collection.find(query)
            return [doc for doc in cursor]
        except Exception as e:
            print(f"An error occurred while querying documents: {e}")
            return []

    def update(self, query, new_values):
        """Update documents in the collection"""
        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return True, result.modified_count
        except Exception as e:
            print(f"An error occurred while updating documents: {e}")
            return False, 0

    def delete(self, query):
        """Delete documents from the collection"""
        try:
            result = self.collection.delete_many(query)
            return True, result.deleted_count
        except Exception as e:
            print(f"An error occurred while deleting documents: {e}")
            return False, 0


# Example usage:
if __name__ == "__main__":
    # Initialize the CRUD object
    crud = AnimalShelterCRUD(
        username='aacuserr',
        password='SNHU1234',
        host='nv-desktop-services.apporto.com',
        port=31384,
        db_name='AAC',
        collection_name='animals'
    )


    # Query documents
    print("Querying for Pug breed...")
    query = {"breed": "Pug"}
    dogs = crud.read(query)
    print(f"Dogs found: {len(dogs)}\nDetails: {dogs}\n")

    # Example data to insert
    example_data = {"age_upon_outcome": "2 years", "animal_id": "B746874", "animal_type": "Dog", "breed": "Pug", "date_of_birth": "4/10/2014", "datetime": "4/11/2017 9:00", "name": "Archer", "outcome_subtype": "Transfer", "sex_upon_outcome": "Neutered Male", "location_lat": 30.50665787, "location_long": -97.34087807, "age_upon_outcome_in_weeks": 145.949}

    # Create a document
    print("Attempting to insert document...")
    if crud.create(example_data):
        print("Document inserted successfully!\n")
    else:
        print("Failed to insert document.\n")
    
    # Query documents
    print("Querying for Pug breed...")
    query = {"breed": "Pug"}
    dogs = crud.read(query)
    print(f"Dogs found: {len(dogs)}\nDetails: {dogs}\n")

    
    
    
    # Update documents
    print("Updating outcome_subtype for Pug breed...")
    update_query = {"breed": "Pug"}
    new_values = {"outcome_subtype": "Adopted"}
    success, count = crud.update(update_query, new_values)
    if success:
        print(f"Successfully updated {count} documents.\n")
    else:
        print("Failed to update documents.\n")

    # Query again to verify update
    print("Verifying updates for Pug breed...")
    updated_dogs = crud.read(query)
    print(f"Updated dogs found: {len(updated_dogs)}\nDetails: {updated_dogs}\n")

    # Delete a document
    print("Deleting a document with animal_id B746874...")
    delete_query = {"animal_id": "B746874"}
    success, count = crud.delete(delete_query)
    if success:
        print(f"Successfully deleted {count} documents.\n")
    else:
        print("Failed to delete document.\n")

    # Verify deletion
    print("Verifying deletion for animal_id B746874...")
    deleted_dog = crud.read({"animal_id": "B746874"})
    if not deleted_dog:
        print("Document successfully deleted, no entry found.")
    else:
        print(f"Document deletion failed, entry found: {deleted_dog}")
